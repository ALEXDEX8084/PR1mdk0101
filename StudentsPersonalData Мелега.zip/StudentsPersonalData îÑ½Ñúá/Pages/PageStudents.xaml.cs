﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StudentsPersonalData.Pages;
using StudentsPersonalData.Classes;

namespace WpfSql.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageUser.xaml
    /// </summary>
    public partial class PageUser : Page
    {
        public PageUser()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = StudentsPersonalDBEntities.GetContext().Person.ToList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        //Редактирование пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq((sender as Button).DataContext as Person));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        // Добавление пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких пользователей
            var personForRemoving = DGridUsers.SelectedItems.Cast<Person>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    StarodubcevEntities.GetContext().Person.RemoveRange(personForRemoving);
                    StarodubcevEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = StarodubcevEntities.GetContext().Person.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                StarodubcevEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = StarodubcevEntities.GetContext().Person.ToList();
            }
        }
    }
}

